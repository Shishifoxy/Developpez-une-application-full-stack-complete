package com.openclassrooms.mddapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MddApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
